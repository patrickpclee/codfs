#pragma once
namespace mongo {
    namespace shell_utils {
        extern mongo::mutex &mongoProgramOutputMutex;
    }
}
