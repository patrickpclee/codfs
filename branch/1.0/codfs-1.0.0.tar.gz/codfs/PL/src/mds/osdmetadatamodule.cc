#include "osdmetadatamodule.hh"


