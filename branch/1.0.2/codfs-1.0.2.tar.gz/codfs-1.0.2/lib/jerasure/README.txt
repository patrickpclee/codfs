This is revision 1.2A of Jerasure.  It is basically equivalent to revision 1.2
except it is released under the New BSD license.

See technical report CS-08-627 for a description of the code.  

There are two directories:

The home directory contains the jerasure code.

The Examples directory contains the example programs.  

The makefile assumes that Examples is a subdirectory of the home directory.
