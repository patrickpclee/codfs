#ifndef __ALL_CODING_HH__
#define __ALL_CODING_HH__

#include "raid0coding.hh"
#include "raid1coding.hh"
#include "raid5coding.hh"
#include "rscoding.hh"
#include "embrcoding.hh"
#include "cauchycoding.hh"
#include "evenoddcoding.hh"
#include "rdpcoding.hh"

#endif
